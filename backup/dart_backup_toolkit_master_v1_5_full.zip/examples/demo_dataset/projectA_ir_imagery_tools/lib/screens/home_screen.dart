// projectA home_screen.dart
// older version
