#!/usr/bin/env bash
set -euo pipefail

echo "[bash53] Building Bash 5.3 parallel-install RPM for Rocky/RHEL..."

TOPDIR="${HOME}/rpmbuild"
SPEC="bash53.spec"
PKGNAME="bash53"
VERSION="5.3"

# 1. Ensure rpmbuild tree
mkdir -p "${TOPDIR}"/{BUILD,RPMS,SOURCES,SPECS,SRPMS}
if [[ ! -f "${HOME}/.rpmmacros" ]]; then
    echo "%_topdir ${TOPDIR}" > "${HOME}/.rpmmacros"
    echo "[bash53] Created ~/.rpmmacros pointing to ${TOPDIR}"
fi

# 2. Install basic build dependencies (Rocky/RHEL 8/9)
echo "[bash53] Installing build dependencies (requires sudo)..."
sudo dnf install -y gcc make rpm-build ncurses-devel curl

# 3. Copy spec file
echo "[bash53] Copying spec file..."
cp "$(dirname "$0")/../SPECS/${SPEC}" "${TOPDIR}/SPECS/"

# 4. Download source tarball if missing
cd "${TOPDIR}/SOURCES"
TARBALL="bash-5.3.tar.gz"
if [[ ! -f "${TARBALL}" ]]; then
    echo "[bash53] Downloading Bash 5.3 source tarball..."
    curl -O https://ftp.gnu.org/gnu/bash/${TARBALL}
else
    echo "[bash53] Found existing ${TARBALL}, reusing."
fi

# 5. Build RPM
cd "${TOPDIR}/SPECS"
echo "[bash53] Running rpmbuild -ba ${SPEC} ..."
rpmbuild -ba "${SPEC}"

echo
echo "[bash53] Done. Look for the RPM under:"
echo "  ${TOPDIR}/RPMS/x86_64/${PKGNAME}-${VERSION}-*.rpm"
