#!/usr/bin/env bash
set -euo pipefail

echo "[bash53] Uninstalling bash53 RPM..."
echo "[bash53] If your login shell is /usr/local/bin/bash53, you should run:"
echo "    chsh -s /bin/bash"
echo "before uninstalling."

sudo rpm -e bash53 || {
  echo "[bash53] Failed to uninstall bash53. Is it installed?"
  exit 1
}

echo "[bash53] Done."
