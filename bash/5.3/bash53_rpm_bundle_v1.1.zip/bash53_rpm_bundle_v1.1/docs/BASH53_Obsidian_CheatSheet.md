---
tags:
  - bash
  - bash53
  - bash-upgrade
  - rocky-linux
  - shell
created: 2025-12-03
title: "Bash 5.2 → 5.3 Upgrade Notes"
---

# Bash 5.2 → 5.3 Upgrade Cheat Sheet

A quick reference for what's new or changed between **Bash 5.1 → 5.2 → 5.3**,
focused on scripting impact and "gotchas". This is aimed at Rocky/RHEL users
running a parallel `bash53` alongside the system `bash`.

---

## 1. Version Check

```bash
bash --version     # system bash
bash53 --version   # new parallel-install bash
```

Pin your scripts explicitly to Bash 5.3 when you want its behavior:

```bash
#!/usr/local/bin/bash53
set -euo pipefail
```

---

## 2. Parameter Expansion Enhancements

### 2.1 `${var@operator}` behavior tightened

Transform expansions like:

```bash
${var@U}   # uppercase
${var@L}   # lowercase
${var@Q}   # shell-quoted
```

In newer Bash, invalid transforms or invalid parameter names now produce
**clearer errors**, making script failures more obvious instead of silently
doing the wrong thing.

**Takeaway:** if you relied on undefined `${x@something}` behavior, it may now
fail loudly (good for correctness).

---

## 3. Indirect Expansion & Name References

Bash 5.2+ continues to solidify behavior around:

```bash
${!prefix*}
${!prefix@}
```

These expand to variable names starting with `prefix`. The behavior is more
consistent and less dependent on internal ordering.

**Use case:** building dashboards, "env-like" dumpers, or meta-scripts that
iterate over structured variable sets (`CFG_...`, `JOB_...`, etc.).

---

## 4. Arrays & Subshell Behavior

Several fixes affect arrays and subshells:

- More predictable expansion order for **indexed arrays**
- Fewer corner-case surprises when using `local` + arrays inside functions
- Safer behavior when arrays are manipulated within command substitutions:

```bash
mapfile -t lines < <(some_command)
```

**Practical impact:** large scripting frameworks (like your `scripts/` repo)
get more reliable, less "Heisenbuggy" behavior across platforms.

---

## 5. `coproc` Improvements

`coproc` allows easy asynchronous pipelines:

```bash
coproc myjob { long_running_command; }

# Write to coprocess stdin:
echo "data" >&"${myjob[1]}"

# Read from coprocess stdout:
read -r line <&"${myjob[0]}"
```

Bash 5.2/5.3 include:

- Better file descriptor management
- Reduced risk of race conditions or prematurely closed pipes

**Where this helps you:**

- Parallel file scanning tools
- Asynchronous log processors
- fzf-backed dashboards that stream data

---

## 6. Readline (Line Editing) Enhancements

Bash 5.3 bundles a newer **Readline**, which improves:

- **Bracketed paste mode**
  - Pasting multi-line snippets is safer (less chance of partial-execution)
- **UTF-8 handling**
  - Better alignment and cursor movement in Unicode-heavy prompts
- **Meta-key and Alt-key handling**
  - More consistent behavior over SSH, tmux, etc.
- Undo/redo behavior feels more predictable

**You notice this in:**
- Custom prompts
- Heavily themed shells
- Long editing sessions in your `bash53` shell

---

## 7. New / Useful Shell Options

Some options were added or polished in 5.2+:

### 7.1 `globskipdots`

When enabled, globbing skips `.` and `..`:

```bash
shopt -s globskipdots
printf '%s\n' *      # will not list . or ..
```

### 7.2 `shift_verbose`

Warn when `shift` goes past available parameters:

```bash
set -o shift_verbose
shift 10              # emits diagnostic if not enough args
```

**Why this matters:** safer argument-handling in complex scripts.

---

## 8. Security & Robustness Fixes

Bash 5.2–5.3 include many small but important hardening changes:

- More careful HEREDOC handling
- Reduced risk of leaking file descriptors to child processes
- Safer edge-case handling of associative arrays

These aren't usually visible but increase reliability for long-running or
security-sensitive scripts.

---

## 9. Recommendations for Your Scripts

1. **Pin interpreter for new scripts:**

   ```bash
   #!/usr/local/bin/bash53
   ```

2. **Use safer shopt options:**

   ```bash
   shopt -s globskipdots
   set -o shift_verbose
   ```

3. **Be explicit about assumptions:**

   - If you depend on specific array ordering, document it.
   - For meta-scripting using `${!prefix*}`, test under both system bash and
     `bash53` once.

4. **Testing pattern:**

   ```bash
   for shell in /bin/bash /usr/local/bin/bash53; do
       echo "== Testing with $shell =="
       "$shell" -n your_script.sh || exit 1
   done
   ```

---

## 10. Obsidian Dataview Integration

If you keep multiple Bash notes, add a Dataview block:

```dataview
table file.link as Note, created
from ""
where contains(tags, "bash-upgrade")
sort created asc
```

Tag this note with: `#bash-upgrade` `#bash53` `#rocky-linux`.

---

## 11. Quick Checklist for Migrating Scripts

- [ ] Shebang updated to `/usr/local/bin/bash53` for scripts needing 5.3
- [ ] `set -euo pipefail` used in critical scripts
- [ ] `shift` behavior tested with `shift_verbose`
- [ ] Any use of `${var@op}` checked for invalid operators
- [ ] Meta-expansions `${!prefix*}` tested under both shells
- [ ] Long-running or asynchronous scripts tried under `bash53` once

---

**Bottom line:**  
Upgrading to Bash 5.3 gives you **more predictable scripting** and a better
interactive shell, especially on Rocky/RHEL where the system bash can lag
behind. Use `bash53` for new work while leaving `/bin/bash` untouched for the
OS.
