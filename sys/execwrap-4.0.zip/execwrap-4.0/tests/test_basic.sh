#!/bin/bash
echo Test basic