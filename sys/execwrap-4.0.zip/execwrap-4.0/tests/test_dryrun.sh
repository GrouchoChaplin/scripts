#!/bin/bash
echo Test dryrun