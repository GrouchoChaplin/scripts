#!/bin/bash
echo Test clean