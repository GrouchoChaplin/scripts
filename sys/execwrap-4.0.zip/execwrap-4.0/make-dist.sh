#!/bin/bash
echo Making dist