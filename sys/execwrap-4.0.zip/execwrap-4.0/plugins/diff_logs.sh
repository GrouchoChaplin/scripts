#!/bin/bash
echo Diff plugin