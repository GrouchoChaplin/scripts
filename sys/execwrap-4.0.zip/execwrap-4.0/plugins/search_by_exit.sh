#!/bin/bash
echo Search plugin